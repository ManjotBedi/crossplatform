
    function Function() {
      var name = document.getElementById("name");
        var oldpasswprd = document.getElementById('oldPassword').value;
        var newpassword = document.getElementById('newPassword').value;
        var confirmpassword = document.getElementById('confirmPassword').value;
        if (oldPassword == "" || newpassword == "" || confirmpassword == "") {
            alert('Please fill all the details');
        }
        else if (oldpasswprd == newpassword) {
            alert("Old password and New Password cannot be same");
        }
        else if (newpassword != confirmpassword) {
            alert("password mismatch");
        }
        else if (newpassword == confirmpassword){


     if (localStorage.getItem('user1') == name){
       if (localStorage.getItem('user1pass') == oldpasswprd){
 localStorage.setItem('user1pass',newpassword);
   alert("password saved");
 }
 else{
   aleart("Password mismatch");
 }
 }
   else  {
     if (localStorage.getItem('user2') == name){
         if (localStorage.getItem('user2pass') == oldpasswprd){
   localStorage.setItem('user2pass',newpassword);
   alert("password saved");
 }
else{
 aleart("Password mismatch");
}}
   else {
     alert("Please enter correct username");
     }
}
// location.reload();

   }

}
