/*var name = document.getElementById("name");
var password = document.getElementById("password");
function check(form){
if (form.name.value == "test" && form.password.value == "test")
{
url ='file:///C:/Users/MeraNaam/Desktop/HTML-CSS-JS-master/loggedin.html?name=' + name;
document.location.href = url;
}
else {
alert ("Invalid User");
}
}
*/
function check(form){

var name = document.getElementById("name");
var password = document.getElementById("password");
if (form.name.value == "Test" && form.password.value == "test")
{
  alert("You are loging in");
   document.location.href = "loggedin.html?name="+name.value;

}

else if(form.name.value == "Manjot" && form.password.value == "manjot"){
  document.location.href = "loggedin.html?name="+name.value;
}
else {
  alert("Wrong username or password");
}
return false;
}
function changePassword()
{
  document.getElementById("Username").innerHTML = name;
  // document.getElementById("home").style.display = "none";
  // document.getElementById("changePasswordView").style.display = "block";
  document.getElementById("currentPassword").value = '';
  document.getElementById("newPassword").value = '';
  document.getElementById("currentPassword").style.backgroundColor = "white";
  document.getElementById("newPassword").style.backgroundColor = "white";
}

function passchange()
{
  var c = document.getElementById("currentPassword").value;
  var n = document.getElementById("newPassword").value;
  document.getElementById("currentPassword").parentElement.style.borderColor = "#cccccc";
  document.getElementById("newPassword").parentElement.style.borderColor = "#cccccc";
  if(c == '' && n == ''){
    document.getElementById("currentPassword").parentElement.style.borderColor = "red";
    document.getElementById("newPassword").parentElement.style.borderColor = "red";
  }else if(c == '' && n != ''){
    document.getElementById("currentPassword").parentElement.style.borderColor = "red";
  }
  else if(c != '' && n == ''){
    document.getElementById("newPassword").parentElement.style.borderColor = "red";
  }
  else if(c == user_pass_list[name])
  {
    p1 = document.getElementById("newPassword").value;
    user_pass_list[name] = document.getElementById("newPassword").value;
    alert("Password changed");
    document.getElementById("home").style.display = "block";
    // document.getElementById("changePasswordView").style.display = "none";
  }
  else
  {
    alert("Enter correct Password");
  }
}
