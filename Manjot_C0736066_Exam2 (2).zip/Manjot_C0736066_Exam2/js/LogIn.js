function clearAll(){
  alert("CLEAR LOCAL STORAGE");
localStorage.clear();
}

window.onload=function(){

    var url = document.location.href, params = url.split('?')[1].split('&'),data ={}, tmp;
  //alert(url);
    for (var i = 0, l = params.length; i<1; i++){
      tmp = params[i].split('=');
      data[tmp[0]] = tmp[1];
    }
  //alert(data.name);
    document.getElementById('name').innerHTML = data.name;
var sbalance=localStorage.getItem('sbalance');
var tbalance=localStorage.getItem('tbalance');
var sCreditAvilable=localStorage.getItem('sCreditAvilable');
var tCreditAvilable=localStorage.getItem('tCreditAvilable');
if(sbalance == null && tbalance == null && sCreditAvilable == null && tCreditAvilable == null){
  sbalance=1000;
  tbalance=1000;
  sCreditAvilable=1000;
  tCreditAvilable=1000;
  localStorage.setItem('sbalance',sbalance);
  localStorage.setItem('tbalance', tbalance);
  localStorage.setItem('sCreditAvilable', sCreditAvilable);
  localStorage.setItem('tCreditAvilable', tCreditAvilable);
}


  document.getElementById("cbal").value=sbalance;
  document.getElementById("bal").value=sbalance;
  document.getElementById("avbal").value=sCreditAvilable;

}

/*
function currentbal()
{

    if (cbal == null)
    {
  localStorage.setItem('balance', '1000');
}
else
{
    var cbal = localStorage.getItem('balance');
}
document.getElementById("cbal").value;
}
*/
function btntrans() {
  var sbalance=localStorage.getItem('sbalance');
   console.log(sbalance);
  var tbalance=0;
  tbalance=localStorage.getItem('tbalance');
  var sCreditAvilable=localStorage.getItem('sCreditAvilable');
  var tCreditAvilable=localStorage.getItem('tCreditAvilable');

  var bal = document.getElementById("bal");

  var crbal = document.getElementById("crbal");
   var avbal = document.getElementById("avbal");
  if (bal == null){
    localStorage.setItem('balance', '1000')
  }
  else {
    document.getElementById("cbal").value;
    var amt = document.getElementById("amt");


     if (amt.value < cbal.value) {

      bal.value = cbal.value - amt.value;
alert("Transfer Successful");
     }
     if (amt.value > cbal.value) {
     if(amt.value > (parseInt(avbal.value)+parseInt(cbal.value))){
     alert("ERROR! Amount cannot be tranfered");
     location.reload();
     }

else{


      var temp=crbal.value - (amt.value - cbal.value);
       sbalance = 0;
      sCreditAvilable=  crbal.value - (amt.value - cbal.value);
      console.log(amt.value);
     tbalance=  (parseInt(tbalance) + parseInt(amt.value));
     console.log(tbalance);
       avbal.value=sCreditAvilable;
       bal.value =0;
       cbal.value =0;
       amt.value=0;
       alert("Transfer Successful");
     }
   }

  }
    //localStorage.setItem('balance', bal.value);
    localStorage.setItem('sbalance',bal.value);
    localStorage.setItem('tbalance', tbalance);
    localStorage.setItem('sCreditAvilable', sCreditAvilable);
    //localStorage.setItem('balance', bal.value);
}
function btnsubmit()
{
 btntrans();

}

function summary(){
	document.getElementById("login").style.display = "none";

	document.getElementById("summary").style.display = "block";
}

// function btntrans()
// {
//   var bal = document.getElementById("bal");
//   var currentBalance = 1000;
//   var amount = document.getElementById("amt");
//   if(currentBalance > amount)
//   {
//     document.getElementById("bal").value = currentBalance - amount;
//     currentBalance =
//   }
//   else if(currentBalance < amount)
//   {
//     alert("You do not have sufficient balance.");
//   }
// }
//
// function btnsubmit()
// {
//   btntrans();
// }
