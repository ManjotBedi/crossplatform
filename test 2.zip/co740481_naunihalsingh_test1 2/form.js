var user = "naunihal";
var paswrd = "1";

function check(form)
{
var u1 = document.getElementById("user");
var p1 = document.getElementById("enter");

if(u1.value == user && p1.value == paswrd)
{
  window.open("login.html");
  return true;
}
else {
  alert("not ok");
  return false;
}
}
function validatePrice(){
  var amount = document.getElementById("amount").value;


  if(1 > 0 ){
    if (isNaN(amount)){
      alert("Enter Valid Amount");
    }
    else{
        //alert(price);
        if(amount > 2000){
            alert("Insufficient Balance");
        }
        else if(amount < 0){
            alert("Enter valid amount");
        }
        else{
            var balance = 2000 - amount;
            //alert(balance);
            var updatedBalance =  document.getElementById("final");
            updatedBalance.value = balance;
        }
    }
  }
  else{
    alert("Transfer should be made to a different account");
  }

}

function changeP()
{
  var pPass = document.getElementById("pPass").value;
  var nPass = document.getElementById("nPass").value;
  if(pPass == paswrd)
  {
      paswrd= nPass;
      alert("Password changed");
      window.open("login.html");
  }
  else {
    alert("Wrong current Password");
  }
}
